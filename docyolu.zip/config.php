<?php
/**
 * Doçentlik Yolu - Konfigürasyon
 * Basit tek kullanıcı sistemi
 */

// Kullanıcı bilgileri - İSTEDİĞİNİZ GİBİ DEĞİŞTİRİN
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'admin'); // Şifrenizi buradan değiştirin

// Oturum süresi (saniye) - 7 gün
define('SESSION_DURATION', 7 * 24 * 60 * 60);
define('SESSION_TIMEOUT', 7 * 24 * 60 * 60); // Alias for SESSION_DURATION

// Veri dizinleri
define('DATA_DIR', __DIR__ . '/data');
define('KRITERLER_DIR', __DIR__ . '/kriterler');
